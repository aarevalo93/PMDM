package com.example.recuejercicio2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Toast;

import java.security.spec.RSAKeyGenParameterSpec;

public class MainActivity extends AppCompatActivity {

    SeekBar skRojo, skVerde, skAzul, skTamano;
    RadioGroup rdgFuente;
    RadioButton rdShojumaru, rdLeckerli, rdRocker;
    EditText edtMensaje;
    Button btnGuardarTodo, btnGuardarColor, btnGuardarTamano, btnGuardarFuente, btnGuardarTexto;
    Button btnCargarTodo, btnCargarColor, btnCargarTamano, btnCargarFuente, btnCargarTexto;

    SharedPreferences preferencias;
    String prefName= "Mis preferencias";

    static final String FONT_SIZE_KEY = "fonttam";
    static final String TEXT_VALUE_KEY = "valortexto";
    static final String RED_VALUE_KEY = "valorrojo";
    static final String GREEN_VALUE_KEY = "valorverde";
    static final String BLUE_VALUE_KEY = "valorazul";

    int progreso;
    int intR=0;
    int intG=0;
    int intB=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        skRojo=(SeekBar)findViewById(R.id.skRojo);
        skAzul=(SeekBar)findViewById(R.id.skAzul);
        skVerde=(SeekBar)findViewById(R.id.skVerde);
        skTamano=(SeekBar)findViewById(R.id.skTamano);
        rdgFuente=(RadioGroup)findViewById(R.id.rdgFuente);
        rdShojumaru =(RadioButton)findViewById(R.id.radioShojumaru);
        rdLeckerli=(RadioButton)findViewById(R.id.radioLeckerli);
        rdRocker=(RadioButton)findViewById(R.id.radioRocker);
        btnGuardarTodo=(Button)findViewById(R.id.btnGuardarTodo);
        btnGuardarTexto=(Button)findViewById(R.id.btnGuardarTexto);
        btnGuardarColor=(Button)findViewById(R.id.btnGuardarColor);
        btnGuardarTamano=(Button)findViewById(R.id.btnGuardarTamano);
        btnGuardarFuente=(Button)findViewById(R.id.btnGuardarFuente);
        btnCargarTodo=(Button)findViewById(R.id.btnCargarTodo);
        btnCargarTexto=(Button)findViewById(R.id.btnCargarTexto);
        btnCargarColor=(Button)findViewById(R.id.btnCargarColor);
        btnCargarTamano=(Button)findViewById(R.id.btnCargarTamano);
        btnCargarFuente=(Button)findViewById(R.id.btnCargarFuente);
        edtMensaje =(EditText)findViewById(R.id.edtMensaje);

        rdShojumaru.setTypeface(ResourcesCompat.getFont(this,R.font.shojumaruregular));
        rdLeckerli.setTypeface(ResourcesCompat.getFont(this,R.font.leckerlioneregular));
        rdRocker.setTypeface(ResourcesCompat.getFont(this,R.font.newrockerregular));


        //********************************************************

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            skTamano.setMin(0);
            skTamano.setMax(10);
        }

        skTamano.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {

                progreso=i;

                if(progreso==0)edtMensaje.setTextSize(10);
                if(progreso==10)edtMensaje.setTextSize(60);
                else edtMensaje.setTextSize((progreso*(50/9)+10));
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            skRojo.setMin(0);
            skRojo.setMax(255);
            skVerde.setMin(0);
            skVerde.setMax(255);
            skAzul.setMin(0);
            skAzul.setMax(255);

            skRojo.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    intR = skRojo.getProgress();
                    edtMensaje.setTextColor(Color.argb(250,intR,intG,intB));
                }
                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {}
                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {}
            });

            skVerde.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    intG = skVerde.getProgress();
                    edtMensaje.setTextColor(Color.argb(250,intR,intG,intB));
                }
                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {}
                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {}
            });

            skAzul.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    intB = skAzul.getProgress();
                    edtMensaje.setTextColor(Color.argb(250,intR,intG,intB));
                }
                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {}
                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {}
            });
        }

        rdgFuente.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId==R.id.radioShojumaru){
                    edtMensaje.setTypeface(ResourcesCompat.getFont(getApplicationContext(),R.font.shojumaruregular));
                };
                if (checkedId==R.id.radioLeckerli){
                    edtMensaje.setTypeface(ResourcesCompat.getFont(getApplicationContext(),R.font.leckerlioneregular));
                };
                if (checkedId==R.id.radioRocker){
                    edtMensaje.setTypeface(ResourcesCompat.getFont(getApplicationContext(),R.font.newrockerregular));
                };
            }
        });

        btnGuardarTodo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                preferencias = getPreferences(MODE_PRIVATE);
                SharedPreferences.Editor editor = preferencias.edit();

                editor.putFloat(FONT_SIZE_KEY, (float)progreso);
                editor.putString(TEXT_VALUE_KEY, edtMensaje.getText().toString());
                editor.putInt(RED_VALUE_KEY, intR);
                editor.putInt(GREEN_VALUE_KEY, intG);
                editor.putInt(BLUE_VALUE_KEY, intB);
                editor.putBoolean("shojumaru", rdShojumaru.isChecked());
                editor.putBoolean("leckerli", rdLeckerli.isChecked());
                editor.putBoolean("rocker", rdRocker.isChecked());

                editor.commit();

                Toast.makeText(getBaseContext(), "Datos almacenados", Toast.LENGTH_LONG).show();
            }
        });

        btnCargarTodo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                preferencias = getPreferences(MODE_PRIVATE);
                int red = preferencias.getInt(RED_VALUE_KEY, 0);
                int green = preferencias.getInt(GREEN_VALUE_KEY, 0);
                int blue = preferencias.getInt(BLUE_VALUE_KEY, 0);
                skRojo.setProgress(red);
                skVerde.setProgress(green);
                skAzul.setProgress(blue);

                float fontSize = preferencias.getFloat(FONT_SIZE_KEY, 4);
                skTamano.setProgress((int)fontSize);
                edtMensaje.setText(preferencias.getString(TEXT_VALUE_KEY, ""));
                edtMensaje.setTextColor(Color.argb(250,red,green,blue));

                if(skTamano.getProgress()==0)edtMensaje.setTextSize(10);
                if(skTamano.getProgress()==10)edtMensaje.setTextSize(60);
                else edtMensaje.setTextSize((skTamano.getProgress()*(50/9)+10));

                rdShojumaru.setChecked(preferencias.getBoolean("shojumaru", false));
                rdLeckerli.setChecked(preferencias.getBoolean("leckerli", false));
                rdRocker.setChecked(preferencias.getBoolean("rocker", false));

                if(rdShojumaru.isChecked()) edtMensaje.setTypeface(ResourcesCompat.getFont(getApplicationContext(),R.font.shojumaruregular));
                if(rdLeckerli.isChecked()) edtMensaje.setTypeface(ResourcesCompat.getFont(getApplicationContext(),R.font.leckerlioneregular));
                if(rdRocker.isChecked()) edtMensaje.setTypeface(ResourcesCompat.getFont(getApplicationContext(),R.font.newrockerregular));
            }
        });

        btnGuardarColor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                preferencias = getPreferences(MODE_PRIVATE);
                SharedPreferences.Editor editor = preferencias.edit();

                editor.putInt(RED_VALUE_KEY, intR);
                editor.putInt(GREEN_VALUE_KEY, intG);
                editor.putInt(BLUE_VALUE_KEY, intB);

                editor.commit();

                Toast.makeText(getBaseContext(), "Color almacenado", Toast.LENGTH_LONG).show();

            }
        });

        btnCargarColor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                preferencias = getPreferences(MODE_PRIVATE);
                int red = preferencias.getInt(RED_VALUE_KEY, 0);
                int green = preferencias.getInt(GREEN_VALUE_KEY, 0);
                int blue = preferencias.getInt(BLUE_VALUE_KEY, 0);
                skRojo.setProgress(red);
                skVerde.setProgress(green);
                skAzul.setProgress(blue);

                edtMensaje.setTextColor(Color.argb(250,red,green,blue));
            }
        });

        btnGuardarTexto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                preferencias = getPreferences(MODE_PRIVATE);
                SharedPreferences.Editor editor = preferencias.edit();

                editor.putString(TEXT_VALUE_KEY, edtMensaje.getText().toString());

                editor.commit();

                Toast.makeText(getBaseContext(), "Texto almacenado", Toast.LENGTH_LONG).show();
            }
        });

        btnCargarTexto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                preferencias = getPreferences(MODE_PRIVATE);

                edtMensaje.setText(preferencias.getString(TEXT_VALUE_KEY, ""));

            }
        });

        btnGuardarTamano.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                preferencias = getPreferences(MODE_PRIVATE);
                SharedPreferences.Editor editor = preferencias.edit();
                editor.putFloat(FONT_SIZE_KEY, (float)progreso);
                editor.commit();
                Toast.makeText(getBaseContext(), "Tamaño almacenado", Toast.LENGTH_LONG).show();
            }
        });

        btnCargarTamano.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                preferencias = getPreferences(MODE_PRIVATE);

                float fontSize = preferencias.getFloat(FONT_SIZE_KEY, 4);
                skTamano.setProgress((int)fontSize);
                if(skTamano.getProgress()==0)edtMensaje.setTextSize(10);
                if(skTamano.getProgress()==10)edtMensaje.setTextSize(60);
                else edtMensaje.setTextSize((skTamano.getProgress()*(50/9)+10)); 
            }
        });

        btnGuardarFuente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                preferencias = getPreferences(MODE_PRIVATE);
                SharedPreferences.Editor editor = preferencias.edit();
                editor.putBoolean("shojumaru", rdShojumaru.isChecked());
                editor.putBoolean("leckerli", rdLeckerli.isChecked());
                editor.putBoolean("rocker", rdRocker.isChecked());
                editor.commit();
                Toast.makeText(getBaseContext(), "Fuente almacenada", Toast.LENGTH_LONG).show();
            }
        });

        btnCargarFuente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                preferencias = getPreferences(MODE_PRIVATE);
                rdShojumaru.setChecked(preferencias.getBoolean("shojumaru", false));
                rdLeckerli.setChecked(preferencias.getBoolean("leckerli", false));
                rdRocker.setChecked(preferencias.getBoolean("rocker", false));
                if(rdShojumaru.isChecked()) edtMensaje.setTypeface(ResourcesCompat.getFont(getApplicationContext(),R.font.shojumaruregular));
                if(rdLeckerli.isChecked()) edtMensaje.setTypeface(ResourcesCompat.getFont(getApplicationContext(),R.font.leckerlioneregular));
                if(rdRocker.isChecked()) edtMensaje.setTypeface(ResourcesCompat.getFont(getApplicationContext(),R.font.newrockerregular));
            }
        });
    }
}