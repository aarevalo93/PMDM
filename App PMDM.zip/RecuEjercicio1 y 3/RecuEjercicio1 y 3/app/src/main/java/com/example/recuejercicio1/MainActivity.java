package com.example.recuejercicio1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

   ListView lst_notas;
   private ArrayList<String> notas = new ArrayList<>();
   ArrayAdapter<String> adapter;
   Button btnImportar, btnExportar;


    DBAdapter db = new DBAdapter(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lst_notas=(ListView)findViewById(R.id.lst_notas);
        btnImportar=(Button)findViewById(R.id.btnImportar);
        btnExportar=(Button)findViewById(R.id.btnExportar);

        actualizarListView();

        lst_notas.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                db.open();
                Cursor c = db.consulta(l+1);
                if (c.moveToFirst()) Toast.makeText(getApplicationContext(), "Contenido: " + c.getString(2), Toast.LENGTH_LONG).show();
                db.close();

            }
        });

        lst_notas.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {

                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                LayoutInflater inflater = LayoutInflater.from(MainActivity.this);
                View dialogView = inflater.inflate(R.layout.dialog_nueva_nota, null);
                AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(MainActivity.this);

                EditText edt_titulo = (EditText) dialogView.findViewById(R.id.diagTitulo);
                EditText edt_contenido = (EditText) dialogView.findViewById(R.id.diagContenido);

                dialogBuilder.setView(dialogView)
                        .setPositiveButton("Guardar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                db.open();
                                if(db.actualiza_nota(l+1, edt_titulo.getText().toString(), edt_contenido.getText().toString())){
                                    Toast.makeText(getApplicationContext(), "Nota actualizada", Toast.LENGTH_LONG).show();
                                    actualizarListView();}
                                db.close();
                                dialog.cancel();
                            }
                        })
                        .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        });
                AlertDialog dialogo = dialogBuilder.create();
                dialogo.show();


                return false;
            }
        });


        //*******************EJERCICIO 3*************************

        btnExportar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                LayoutInflater inflater = LayoutInflater.from(MainActivity.this);
                View dialogView = inflater.inflate(R.layout.dialog_exportar, null);
                AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(MainActivity.this);

                EditText edt_archivo = (EditText) dialogView.findViewById(R.id.diagArchivo);

                dialogBuilder.setView(dialogView)
                        .setPositiveButton("Guardar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                String contenido="";
                                try{
                                    FileOutputStream fout = openFileOutput(edt_archivo.getText().toString(), MODE_PRIVATE);

                                    db.open();
                                    Cursor c = db.consulta_todas();
                                    if (c.moveToFirst()) {
                                        do
                                            contenido += c.getString(1) + ";" + c.getString(2)+"\n";
                                        while (c.moveToNext());}

                                        db.close();

                                        OutputStreamWriter osw = new OutputStreamWriter(fout);

                                        osw.write(contenido);
                                        osw.flush();
                                        osw.close();

                                        Toast.makeText(getBaseContext(), "Fichero guardado", Toast.LENGTH_LONG).show();


                                }catch(IOException ioe){ioe.printStackTrace();}
                            }
                        })
                        .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        });
                AlertDialog dialogo = dialogBuilder.create();
                dialogo.show();
            }
        });

        btnImportar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                LayoutInflater inflater = LayoutInflater.from(MainActivity.this);
                View dialogView = inflater.inflate(R.layout.dialog_exportar, null);
                AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(MainActivity.this);

                EditText edt_archivo = (EditText) dialogView.findViewById(R.id.diagArchivo);

                dialogBuilder.setView(dialogView)
                        .setPositiveButton("Importar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                try {
                                    FileInputStream fIn = openFileInput(edt_archivo.getText().toString());
                                    InputStreamReader archivo = new InputStreamReader(fIn);
                                    BufferedReader br = new BufferedReader(archivo);
                                    String linea = br.readLine();
                                    long id;
                                    db.open();
                                    while (linea != null) {
                                        String[] registro = linea.split(";");
                                        id = db.inserta_nota(registro[0], registro[1]);
                                        linea = br.readLine();
                                    }
                                    db.close();
                                    br.close();
                                    archivo.close();
                                    Toast.makeText(getApplicationContext(), "nice", Toast.LENGTH_LONG).show();
                                } catch (IOException e) {
                                    Toast.makeText(getApplicationContext(), "mal", Toast.LENGTH_LONG).show();
                                }
                            }
                        })
                        .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        });
                AlertDialog dialogo = dialogBuilder.create();
                dialogo.show();
            }
        });
        
    }

    //------fin ejercicio 3--------------------------------------------------------------

    void actualizarListView(){
        notas.clear();
        db.open();
        Cursor c = db.consulta_todas();
        if (c.moveToFirst()) {

            do notas.add(c.getString(1));
            while(c.moveToNext());

            adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, notas);
            lst_notas.setAdapter(adapter);

        }
        db.close();
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.nueva_nota:

                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                LayoutInflater inflater = LayoutInflater.from(this);
                View dialogView = inflater.inflate(R.layout.dialog_nueva_nota, null);
                AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);

                EditText edt_titulo = (EditText) dialogView.findViewById(R.id.diagTitulo);
                EditText edt_contenido = (EditText) dialogView.findViewById(R.id.diagContenido);

                dialogBuilder.setView(dialogView)
                        .setTitle("Insertar nota")
                        .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                                db.open();
                                long id = db.inserta_nota(edt_titulo.getText().toString(), edt_contenido.getText().toString());
                                db.close();

                                Toast.makeText(getApplicationContext(),"Nota añadida", Toast.LENGTH_LONG).show();
                                actualizarListView();
                            }
                        })
                        .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Toast.makeText(getApplicationContext(),
                                        "Acción cancelada",
                                        Toast.LENGTH_LONG).show();
                                dialogInterface.cancel();
                            }});
                AlertDialog dialogo = dialogBuilder.create();
                dialogo.show();
                return true;


            default:
                return super.onOptionsItemSelected(item);
        }
    }


    }

