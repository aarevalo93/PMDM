package com.example.recuejercicio1;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DBAdapter {

    public static final String CLAVE_ID = "id";
    public static final String CLAVE_TITLE = "titulo";
    public static final String CLAVE_CONTENT = "contenido";
    private static final String TAG = "DBAdapter";

    private static final String BBDD_NOMBRE = "miBBDD";
    private static final String BBDD_TABLA = "notas";
    private static final int BBDD_VERSION = 1;

    private static final String BBDD_CREAR = "create table notas (id integer primary key autoincrement, titulo text not null, contenido text not null)";

    private final Context context;

    private DatabaseHelper DBHelper;
    private SQLiteDatabase db;

    public DBAdapter(Context ctx) {
        this.context = ctx;
        DBHelper = new DatabaseHelper(context);
    }

    private static class DatabaseHelper extends SQLiteOpenHelper {

        DatabaseHelper(Context context) {
            super(context, BBDD_NOMBRE, null, BBDD_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            try {
                db.execSQL(BBDD_CREAR);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            Log.v(TAG, "Actualizando versión de " + oldVersion + " a " + newVersion + " , se borrarán todos los datos");
            db.execSQL("DROP TABLE IF EXISTS notas");
            onCreate(db);
        }
    }

    public DBAdapter open() throws SQLException {
        db = DBHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        DBHelper.close();
    }

    public long inserta_nota(String titulo, String contenido) {
        ContentValues initialValues = new ContentValues();

        initialValues.put(CLAVE_TITLE, titulo);
        initialValues.put(CLAVE_CONTENT, contenido);
        return db.insert(BBDD_TABLA, null, initialValues);
    }
    

    public Cursor consulta_todas() {

        return db.query(BBDD_TABLA, new String[]{CLAVE_ID, CLAVE_TITLE, CLAVE_CONTENT}, null, null, null, null, null);
    }


    public Cursor consulta(long id_fila) throws SQLException {
        Cursor mcursor = db.query(true, BBDD_TABLA, new String[]{CLAVE_ID, CLAVE_TITLE, CLAVE_CONTENT}, CLAVE_ID + "=" + id_fila, null, null, null, null, null);
        if (mcursor != null) {
            mcursor.moveToFirst();
        }
        return mcursor;
    }


    public boolean actualiza_nota(long id_fila, String titulo, String contenido) {
        ContentValues newValues = new ContentValues();
        newValues.put(CLAVE_TITLE, titulo);
        newValues.put(CLAVE_CONTENT, contenido);
        return db.update(BBDD_TABLA, newValues, CLAVE_ID + "=" + id_fila, null) > 0;
    }

}
